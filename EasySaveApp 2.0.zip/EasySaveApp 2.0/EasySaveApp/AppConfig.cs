﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EasySaveApp
{
    public class AppConfig
    {
        private static AppConfig instance;

        public string DefaultLanguage { get; set; }
        public Dictionary<string, Dictionary<string, string>> Translations { get; set; }

        private AppConfig()
        {
          
            DefaultLanguage = "en";
            Translations = LoadTranslations("language/language.json");
        }

        public static AppConfig Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new AppConfig();
                }
                return instance;
            }
        }

        private Dictionary<string, Dictionary<string, string>> LoadTranslations(string filePath)
        {
            if (File.Exists(filePath))
            {
                string json = File.ReadAllText(filePath);
                return JsonConvert.DeserializeObject<Dictionary<string, Dictionary<string, string>>>(json);
            }
            else
            {
                // Gérez le cas où le fichier n'existe pas
                return new Dictionary<string, Dictionary<string, string>>();
            }
        }
    }
}
