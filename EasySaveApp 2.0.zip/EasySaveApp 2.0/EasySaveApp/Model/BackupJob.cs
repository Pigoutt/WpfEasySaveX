﻿using System;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Text.Json;
using EasySaveApp.ViewModel;
using static EasySaveApp.ViewModel.Encryption;

namespace EasySaveApp.Model
{


    public interface IBackupJobSerializer
    {
        string Serialize(BackupJob job);
    }
    public enum BackupType
    {
        Full,
        Differential
    }
    public class BackupJob : IBackupJobSerializer
    {

       
        public string Name { get; set; }
        public string SourceDirectory { get; set; }
        public string TargetDirectory { get; set; }
        public BackupType Type { get; set; }
        public long TotalSize { get; set; }
        public int TransferTime { get; set; }

        public long EncryptTime { get; set; }





        public BackupJob(string name, string sourceDirectory, string targetDirectory, BackupType type)
        {
            Name = name;
            SourceDirectory = sourceDirectory;
            TargetDirectory = targetDirectory;
            Type = type;


           
            CalculateTotalSize();
            PerformTransfer();
            PerformEncryption();
        }

        private void CalculateTotalSize()
        {
            var directoryInfo = new DirectoryInfo(SourceDirectory);
            var files = directoryInfo.GetFiles("*.*", SearchOption.AllDirectories);
            TotalSize = files.Sum(f => f.Length);
        }

        private void PerformTransfer()
        {
            var stopwatch = new Stopwatch();
            stopwatch.Start();

           //ajouter le code de copie

            stopwatch.Stop();
            TransferTime = (int)stopwatch.Elapsed.TotalSeconds;
        }

        private void PerformEncryption()
        {
            // Ajoutez le code pour simuler le temps d'encryption
            // par exemple, vous pouvez utiliser Stopwatch pour mesurer le temps
            var stopwatch = new Stopwatch();
            stopwatch.Start();

         

            stopwatch.Stop();
            EncryptTime = stopwatch.ElapsedMilliseconds;
        }
        public void Execute()
        {
            var appConfig = AppConfig.Instance;
            string destinationFilePath = Path.Combine(TargetDirectory, Path.GetFileName(SourceDirectory));
            try
            {
                if (Type == BackupType.Full)
                {
                    // Logic for full backup
                    File.Copy(SourceDirectory, destinationFilePath, true);
                    Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["Fullbackupcompleted"]);
                }
                else if (Type == BackupType.Differential)
                {
                    // Logic for differential backup
                    DateTime sourceLastWriteTime = File.GetLastWriteTime(SourceDirectory);
                    DateTime destinationLastWriteTime = File.GetLastWriteTime(destinationFilePath);
                    if (sourceLastWriteTime > destinationLastWriteTime)
                    {
                        File.Copy(SourceDirectory, destinationFilePath, true);
                    }
                    Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["Differentialbackupcompleted"]);
                }
                else
                {
                    throw new InvalidOperationException($"Unsupported backup type: {Type}");
                }



                Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["Backupjob"]); ; Console.WriteLine(Name); Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["executedsuccessfully"]);

            }
            catch (Exception ex)
            {


                Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["failedexecutebackupjob"]); ; Console.WriteLine(Name); Console.WriteLine(ex);
            }
        }

        public string Serialize(BackupJob job)
        {
            return JsonSerializer.Serialize(job);
        }

        private void CopyAll(string source, string destination)
        {
            foreach (string dirPath in Directory.GetDirectories(source, "*", SearchOption.AllDirectories))
            {
                Directory.CreateDirectory(Path.Combine(destination, dirPath.Substring(source.Length + 1)));
            }

            foreach (string filePath in Directory.GetFiles(source, "*", SearchOption.AllDirectories))
            {
                File.Copy(filePath, Path.Combine(destination, filePath.Substring(source.Length + 1)));
            }
        }


        private void CopyChangedFiles(string source, string destination)
        {
            foreach (string filePath in Directory.GetFiles(source, "*.*", SearchOption.AllDirectories))
            {
                string relativePath = filePath.Substring(source.Length + 1);
                string destinationFilePath = Path.Combine(destination, relativePath);

                if (File.Exists(destinationFilePath))
                {
                    DateTime sourceLastWriteTime = File.GetLastWriteTime(filePath);
                    DateTime destinationLastWriteTime = File.GetLastWriteTime(destinationFilePath);

                    if (sourceLastWriteTime > destinationLastWriteTime)
                    {
                        File.Copy(filePath, destinationFilePath, true);
                    }
                    else
                    {
                        File.Copy(filePath, destinationFilePath);
                    }
                }
            }
        }

        public int GetTotalFiles(string source)
        {
            var appConfig = AppConfig.Instance;
            try
            {
                if (File.Exists(source))
                {
                    return 1;
                }
                else if (Directory.Exists(source))
                {
                    return Directory.GetFiles(source, "*", SearchOption.AllDirectories).Length;
                }
                else
                {
                    return 0;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["errorcounting"]);

                return 0;
            }
        }



        private long CalculateTotalSize(string source)
        {
            long totalSize = 0;

            foreach (string file in Directory.GetFiles(source, "*", SearchOption.AllDirectories))
            {
                totalSize += new FileInfo(file).Length;
            }

            return totalSize;
        }
    }
}
