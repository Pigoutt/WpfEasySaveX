﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace EasySaveApp.Model
{
    internal class RealTimeStateFile
    {
        public List<JobState> JobStates { get; set; }
        
        public RealTimeStateFile(List<JobState> jobState) 
        {
            JobStates = jobState;
        }
        
        public string ToJsonString()
        {
            return JsonSerializer.Serialize(this);
        }
    }
}
