﻿using EasySaveApp.Model;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text.Json;

namespace EasySaveApp.ViewModel
{
    interface IJobManager
    {
        BackupJob? CreateBackupJob(string name, string source, string target, string type);
        void ExecuteBackupJob(BackupJob job);
        void ExecuteAllJobsSequentially();
        void ExecuteSelectedJobsSequentially(List<int> selectedJobIndices);
       
        BackupJob? GetBackupJobByName(string backupName);
        void ExecuteBackupJobByName(string backupName);
        void ModifyJob(string jobName, string nwSource, string nwTarget, string nwType);
        void DeleteJob(string jobName);
        List<int> ParseBackupIndices(string input);
        void ExecuteSelectedBackups(List<BackupJob> backupJobs, List<int> indices);

    }
    public class JobManager : IJobManager
    {

        public readonly List<BackupJob> _backupJobs;
        private readonly List<BackupLog> _logEntries;
        private const string LogFilePath = "backupLog.json";
       



        public JobManager(List<BackupJob> backupJobs)
        {
           
            _backupJobs = backupJobs;
            _logEntries = new List<BackupLog>();
           
        }

        public BackupJob? CreateBackupJob(string name, string source, string target, string type)
        {
            var appConfig = AppConfig.Instance;
            if (_backupJobs.Any(job => job.Name.Equals(name, StringComparison.OrdinalIgnoreCase)))
            {
                Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["Backupjob"]); Console.WriteLine(name); Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["Choosedifferentname"]);
                return null;
            }

            var backupJob = new BackupJob(name, source, target, Enum.Parse<BackupType>(type));
            _backupJobs.Add(backupJob);
            return backupJob;


        }

        public void ModifyJob(string jobName, string source, string target, string type)
        {
            var appConfig = AppConfig.Instance;
            var backupJob = GetBackupJobByName(jobName);
            if (backupJob != null)
            {
                backupJob.SourceDirectory = source;
                backupJob.TargetDirectory = target;


                Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["Backupjob"]); Console.WriteLine(backupJob.Name); Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["modifysucces"]);
            }
            else
            {
                Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["Backupjob"]); Console.WriteLine(jobName); Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["notfound"]);




            }
        }

        public void DeleteJob(string jobName)
        {
            var appConfig = AppConfig.Instance;
            var backupJob = GetBackupJobByName(jobName);
            if (backupJob != null)
            {
                _backupJobs.Remove(backupJob);
                Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["Backupjob"]); Console.WriteLine(backupJob.Name); Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["deletedsucces"]);
            }
            else
            {
                Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["Backupjob"]); Console.WriteLine(jobName); Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["deletedfailed"]);
            }
        }
        public BackupJob? GetBackupJobByName(string backupName)
        {
            return _backupJobs.FirstOrDefault(job => job.Name.Equals(backupName, StringComparison.OrdinalIgnoreCase));
        }
        public void ExecuteBackupJobByName(string backupName)
        {
            var appConfig = AppConfig.Instance;
            try
            {
                var backupJob = GetBackupJobByName(backupName);

                if (backupJob != null)
                {
                    ExecuteBackupJob(backupJob);
                }
                else
                {
                    Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["Backupjob"]); Console.WriteLine(backupName); Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["notfound"]);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["failedexecutebackupjob"]); Console.WriteLine(ex.Message);
            }
        }
      

        public void ExecuteBackupJob(BackupJob job)
        {
            var appConfig = AppConfig.Instance;
            try
            {
                // Vérifiez si le répertoire source contient des fichiers de logiciel métier avant de copier
                if (ContainsBusinessSoftware(job.SourceDirectory))
                {
                    Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["Backupjob"]); Console.WriteLine(job.Name); Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["skipbusinesssoftware"]);
                    return;
                }

                var stopwatch = new Stopwatch();
                stopwatch.Start();

                CopyDirectory(job.SourceDirectory, job.TargetDirectory);

                stopwatch.Stop();
                job.TransferTime = (int)stopwatch.Elapsed.TotalSeconds;

                Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["Backupjob"]); Console.WriteLine(job.Name); Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["executedsuccessfully"]); Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["TransfertTime"]); Console.WriteLine(job.TransferTime); Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["Secondes"]);
            }
            catch (Exception ex)
            {
                Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["failedexecutebackupjob"]); Console.WriteLine(job.Name); Console.WriteLine(ex.Message);
            }
        }
      

        private bool ContainsBusinessSoftware(string directoryPath)
        {
            var appConfig = AppConfig.Instance;
            string[] files = Directory.GetFiles(directoryPath);

            foreach (string filePath in files)
            {
                if (IsBusinessSoftwareExecutable(filePath))
                {
                    Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["Businesssoftware"]); Console.WriteLine(filePath);
                    return true;
                }
            }
            

            return false;
        }

        private bool IsBusinessSoftwareExecutable(string filePath)
        {
            // Liste des extensions associées aux fichiers exécutables
            List<string> executableExtensions = new List<string> { ".exe", ".dll", ".bat", ".cmd" };

            string fileExtension = Path.GetExtension(filePath);

            return executableExtensions.Contains(fileExtension, StringComparer.OrdinalIgnoreCase);
        }
        public void CopyDirectory(string sourceDirectory, string targetDirectory)
        {
            if (!Directory.Exists(targetDirectory))
            {
                Directory.CreateDirectory(targetDirectory);
            }

            foreach (string sourceFilePath in Directory.GetFiles(sourceDirectory))
            {
                string fileName = Path.GetFileName(sourceFilePath);
                string destinationFilePath = Path.Combine(targetDirectory, fileName);
                File.Copy(sourceFilePath, destinationFilePath, true);
            }

            foreach (string sourceSubDirectoryPath in Directory.GetDirectories(sourceDirectory))
            {
                string subDirectoryName = Path.GetFileName(sourceSubDirectoryPath);
                string destinationSubDirectoryPath = Path.Combine(targetDirectory, subDirectoryName);
                CopyDirectory(sourceSubDirectoryPath, destinationSubDirectoryPath);
            }
        }

        public List<int> ParseBackupIndices(string input)
        {
            List<int> indices = new List<int>();

            string[] parts = input.Split(';');


            foreach (string part in parts)
            {
                if (int.TryParse(part, out int index))
                {
                    indices.Add(index);
                }
                else if (part.Contains("-"))
                {
                    string[] rangeParts = part.Split('-');
                    if (rangeParts.Length == 2 && int.TryParse(rangeParts[0], out int start) && int.TryParse(rangeParts[1], out int end))
                    {
                        for (int i = start; i <= end; i++)
                        {
                            indices.Add(i);
                        }
                    }
                }
            }

            return indices.Distinct().ToList();
        }

        public void ExecuteSelectedBackups(List<BackupJob> backupJobs, List<int> indices)
        {
            var appConfig = AppConfig.Instance;
            foreach (int index in indices)
            {
                if (index >= 0 && index < backupJobs.Count)
                {
                    BackupJob selectedBackup = backupJobs[index];
                    ExecuteBackupJob(selectedBackup);
                    Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["Backupjob"]); Console.WriteLine(selectedBackup.Name); Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["executedsuccessfully"]);
                }
             
                else
                {
                    Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["Invalidindex"]); Console.WriteLine(index);
                }
               
            }
        }

        public void ExecuteAllJobsSequentially()
        {
            foreach (var job in _backupJobs)
            {
                ExecuteBackupJob(job);
            }
        }

        public void ExecuteSelectedJobsSequentially(List<int> selectedJobIndices)
        {
            var appConfig = AppConfig.Instance;
            foreach (var index in selectedJobIndices)
            {
                if (index >= 0 && index < _backupJobs.Count)
                {
                    ExecuteBackupJob(_backupJobs[index]);
                }
                else
                {
                    Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["Invalidjobindex"]); ; Console.WriteLine(index); Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["Skip"]);

                }
            }
        }
       

    }
}