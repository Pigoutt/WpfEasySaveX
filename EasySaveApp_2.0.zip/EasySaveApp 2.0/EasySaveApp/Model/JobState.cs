﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace EasySaveApp.Model
{
   public class JobState
    {
        public string Name { get; set; }
        public DateTime Timestamp { get; set; }
        public string Status { get; set; }
        public int TotalFiles { get; set; }
        public long FileSizeToTransfert { get; set; }
        public int Progress { get; set; }
        public int RemainingFiles { get; set; }
        public int RemainingSize { get; set; }
        public string CurrentSourceAddress { get; set; }
        public string TargetAddress { get; set; }
        public string ErrorMessage { get; set; }

        [JsonConstructor]
        public JobState(
            string name,
            DateTime timestamp,
            string status,
            int totalFiles,
            long fileSizeToTransfert,
            int progress,
            int remainingFiles,
            int remainingSize,
            string currentSourceAddress,
            string targetAddress,
            string errorMessage)
        {
            Name = name;
            Timestamp = timestamp;
            Status = status;
            TotalFiles = totalFiles;
            FileSizeToTransfert = fileSizeToTransfert;
            Progress = progress;
            RemainingFiles = remainingFiles;
            RemainingSize = remainingSize;
            CurrentSourceAddress = currentSourceAddress;
            TargetAddress = targetAddress;
            ErrorMessage = errorMessage;
        }

        public string ToJsonString()
        {
            return JsonSerializer.Serialize(this);
        }
    }
}

