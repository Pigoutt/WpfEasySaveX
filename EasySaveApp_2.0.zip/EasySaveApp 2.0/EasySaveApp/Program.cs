﻿using System;
using System.Collections.Generic;
using EasySaveApp.ViewModel;
using EasySaveApp.View;
using EasySaveApp.Model;
using System.Text.Json;
using Newtonsoft.Json;
using static EasySaveApp.ViewModel.Encryption;
using System.Data;

namespace EasySaveApp
{
    internal class Program
    {


        public class LocalizationData
        {
            public Dictionary<string, string> en { get; set; }
        }
        static void Main(string[] args)

        {
            var appConfig = AppConfig.Instance;
            string name;
            string source;
            string target = string.Empty;
            string typeInp;


            string userLogDirectory = string.Empty;

           



            string logDirectory = string.Empty;


            var useLogManager = new LogManager(userLogDirectory);

            
            var backupJobs = new List<BackupJob>();
            var supportedLanguages = new List<string> { "en", "fr" };
            var defaultLanguage = "en"; // Choisissez la langue par défaut
            var languageManager = new LanguageManager(supportedLanguages, defaultLanguage);
            var jobManager = new JobManager(backupJobs);
            var viewModel = new EasySaveAppViewModel(jobManager, languageManager, backupJobs);
            var consoleView = new ConsoleView(languageManager);
            var view = new EasySaveAppView();
            view.DisplayLogo();

            


            // Initialize the TranslationService with the default language(e.g., English)
            var translationService = new TranslationService("language/language.json");


            Dictionary<string, Dictionary<string, string>> translations = LoadTranslations("language/language.json");
           

            Dictionary<string, Dictionary<string, string>> LoadTranslations(string filePath)
            {
                if (File.Exists(filePath))
                {
                    string json = File.ReadAllText(filePath);
                    return JsonConvert.DeserializeObject<Dictionary<string, Dictionary<string, string>>>(json);
                }
                else
                {
                    // Handle the case where the file does not exist
                    return new Dictionary<string, Dictionary<string, string>>();
                }
            }










            while (true)
            {
               
                view.DisplayPrompt();
                string userInput = view.GetUserInput();

                switch (userInput)
                {
                    case "1":
                        Console.Clear();
                        // Affichez les options de langue
                        Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["Chooselanguage"]);
                        Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["Anglais"]);
                        Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["Francais"]);
                        Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["exit"]);
                       
                        // Obtenez l'entrée de l'utilisateur
                        Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["selectOption"]);
                       
                        string choice = Console.ReadLine();

                        switch (choice)
                        {
                            case "1":
                                appConfig.DefaultLanguage = "en";
                                break;

                            case "2":
                                appConfig.DefaultLanguage = "fr";
                                break;

                            case "3":
                                Console.Clear();
                                break;

                            default:
                                Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["Invalidoption"]);
                                break;
                        }
                        break;
                        
                    case "2":
                        Console.Clear();
                        Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["repertorylog"]);
                        userLogDirectory = Console.ReadLine() ?? string.Empty;
                        Console.Clear();
                        // Créez une instance de LogManager en fournissant le chemin du répertoire de logs
                        var userLogManager = new LogManager(userLogDirectory);
                       

                        break;
                    case "3":
                        Console.Clear();
                        Console.WriteLine("");    
                        view.DisplayHM();
                        string backupMenuChoice = view.GetUserInput();
                        switch (backupMenuChoice)
                        {
                            case "1":
                                Console.Clear();
                                Console.WriteLine("");
                                Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["jobdetails"]);

                                do
                                {
                                    Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["jobname"]);
                                    name = Console.ReadLine() ?? string.Empty;
                                } while (string.IsNullOrWhiteSpace(name));
                                do
                                {
                                    Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["Sourcedirectory"]);
                                    source = Console.ReadLine() ?? string.Empty;
                                } while (string.IsNullOrWhiteSpace(source));
                                do
                                {
                                    Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["Targetdirectory"]);
                                    target = Console.ReadLine() ?? string.Empty;
                                    
                                } while (string.IsNullOrWhiteSpace(target));
                                do
                                {
                                    Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["typeBackup"]);
                                    typeInp = Console.ReadLine().ToUpper();
                                } while ((typeInp != "F" && typeInp != "D"));

                                if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(source) || string.IsNullOrWhiteSpace(target) || (typeInp != "F" && typeInp != "D"))
                                {
                                    Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["Invalidoption"]);
                                }


                                string type;
                                switch (typeInp)
                                {
                                    case "F":
                                        type = "Full";
                                        break;
                                    case "D":
                                        type = "Differential";
                                        break;
                                    default:
                                       
                                        type = "Full";
                                        break;
                                }
                               
                                var backupJobcreate = viewModel.CreateBackupJob(name, source, target, type);

                                if (backupJobcreate != null)
                                {
                                    Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["Backupjob"]);
                                    Console.WriteLine(backupJobcreate.Name);
                                    Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["createdsuccessfully"]);
                                    Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["numberofjob"]);
                                    Console.WriteLine(viewModel.backupJobs.Count);
                                    foreach (var job in viewModel.backupJobs)
                                    {
                                        Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["job"]);
                                        Console.WriteLine(job.Name);
                                    }
                                }
                                else
                                {
                                    Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["Failedcreatedjob"]);
                                }
                                break;

                            case "2":
                                Console.Clear();
                                Console.WriteLine("");
                                Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["nametomodify"]);
                                Console.WriteLine("");
                                string jobToModify = Console.ReadLine() ?? string.Empty;
                                var exJob = viewModel.GetBackupJobByName(jobToModify);
                                if (exJob != null)
                                {
                                    
                                    do
                                    {
                                        Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["Sourcedirectory"]);
                                        source = Console.ReadLine() ?? string.Empty;
                                    } while (string.IsNullOrWhiteSpace(source));
                                    do
                                    {
                                        Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["Targetdirectory"]);
                                        target = Console.ReadLine() ?? string.Empty;
                                        
                                    } while (string.IsNullOrWhiteSpace(target));
                                    do
                                    {
                                        Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["typeBackup"]);
                                        typeInp = Console.ReadLine().ToUpper();
                                    } while ((typeInp != "F" && typeInp != "D"));

                                    if ( string.IsNullOrWhiteSpace(source) || string.IsNullOrWhiteSpace(target) || (typeInp != "F" && typeInp != "D"))
                                    {
                                        Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["Invalidoption"]);
                                    }

                                    Console.Clear();
                                    viewModel.ModifyJob(jobToModify, source, target, typeInp);
                                    
                                }
                                else
                                {
                                    Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["Backupjob"]);
                                    Console.WriteLine(jobToModify);
                                    Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["doesnotexist"]);
                                }
                                break;

                            case "3":
                                Console.Clear();
                                Console.WriteLine("");
                                Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["nametodelete"]);
                                string jobToDelete = Console.ReadLine() ?? string.Empty;
                                viewModel.DeleteJob(jobToDelete);
                                break;

                            case "4":
                                Console.Clear();
                                Console.WriteLine("");
                                view.DisplayManageJob();
                                string choiceManage = view.GetUserInput();
                                switch (choiceManage)
                                {
                                    case "1":
                                        Console.Clear();
                                        Console.WriteLine("");
                                        Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["nametolaunch"]);
                                        string jobToRun = Console.ReadLine() ?? string.Empty;
                                        viewModel.ExecuteBackupJobByName(jobToRun);



                                        Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["entercrypto"]);
                                        string crypto = Console.ReadLine() ?? string.Empty;

                                        if (crypto == "yes")
                                        {
                                            CryptoSoftFileEncryptor encryptor = new CryptoSoftFileEncryptor(new List<string> (), "VotreCleXOR");

                                            string targetDire = target;
                                            encryptor.EncryptFilesInDirectory(targetDire);
                                        }

                                        Console.WriteLine("");

                                        if (backupJobs.Count > 0)
                                        {
                                            var backupJobToLog = backupJobs[0]; 

                                            useLogManager.LogBackupJob(backupJobToLog);
                                            
                                        }
                                        else
                                        {
                                            Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["nobackupjob"]);
                                        }
                                        break;

                                    case "2":
                                        Console.Clear();
                                        Console.WriteLine("");
                                        view.DisplayBackupJobs(viewModel.backupJobs);
                                        Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["enterindice"]);
                                        string input = Console.ReadLine() ?? string.Empty;

                                        Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["entercrypto"]);
                                        string crypto1 = Console.ReadLine() ?? string.Empty;

                                       

                                        List<int> indicesToExecute = viewModel.ParseBackupIndices(input);

                                        viewModel.ExecuteSelectedBackups(viewModel.backupJobs, indicesToExecute);

                                        if (crypto1 == "yes")
                                        {
                                            CryptoSoftFileEncryptor encryptor = new CryptoSoftFileEncryptor(new List<string>(), "VotreCleXOR");

                                            string targetDire = target;
                                            encryptor.EncryptFilesInDirectory(targetDire);
                                        }

                                        break;
                                    case "3":
                                        break;


                                    default:
                                        Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["Invalidoption"]);
                                        break;
                                }
                                break;

                            case "5":
                                break;


                            default:
                                Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["Invalidoption"]);
                                break;
                            }
                    break;

                  

                    case "4":
                        Environment.Exit(0);
                        return;

                  
                

                    default:
                        Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["Invalidoption"]);
                        break;
                }
                
            }
        }
    }
}
