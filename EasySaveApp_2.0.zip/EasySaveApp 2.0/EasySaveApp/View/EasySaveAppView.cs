﻿using EasySaveApp.Model;
using EasySaveApp.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using Figgle;
using EasySaveApp;


namespace EasySaveApp.View
{
    internal class EasySaveAppView
    {
       
        

      
        public void DisplayLogo()
        {
            Console.WriteLine(
                    FiggleFonts.Slant.Render("EASY SAVE APP"));
        }
        public void DisplayPrompt()
        {
            var appConfig = AppConfig.Instance;
            Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["welcomeMessage"]);
            Console.WriteLine("");
            Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["selectOption"]);
            Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["modificationlanguage"]);
            Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["logdirectory"]);
            Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["backumanagment"]);
            Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["exit"]);
            Console.WriteLine("");
        }

        public void DisplayHM()
        {
            var appConfig = AppConfig.Instance;
            Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["backumanagment1"]);
            Console.WriteLine("");
            Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["selectOption"]);
            Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["createBackupJob"]);
            Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["configureBackupJob"]);
            Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["deleteBackupJob"]);
            Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["Managebackup1"]);
            Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["exit"]);
            Console.WriteLine("");
        }
        public void DisplayBackupJobs(List<BackupJob> backupJobs)
        {
            var appConfig = AppConfig.Instance;
            Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["Displayingbackupjobs"]);

            if (backupJobs.Count > 0)
            {
                for (int i = 0; i < backupJobs.Count; i++)
                {
                    var job = backupJobs[i];
                    int displayIndex = i;

                    Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["index"]); Console.WriteLine( displayIndex);
                    Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["jobname"]); Console.WriteLine(job.Name);
                    Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["Sourcedirectory"]); Console.WriteLine(job.SourceDirectory);
                    Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["Targetdirectory"]); Console.WriteLine(job.TargetDirectory);
                    Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["typeBackup"]); Console.WriteLine(job.Type);
                    Console.WriteLine();
                }
            }
            else
            {
                Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["Nobackupjobsfound"]);
            }
        }

        public void DisplayManageJob() 
        {
            var appConfig = AppConfig.Instance;
            Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["Managebackup"]);
            Console.WriteLine("");
            Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["selectOption"]);
            Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["launchjob"]);
            Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["launchsequential"]);
            Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["exit"]);
            Console.WriteLine("");
        }

        public string GetUserInput()
        {
            string userInout = Console.ReadLine() ?? string.Empty;
            return userInout ?? string.Empty;
        }

        public void DisplayLogs(string logData)
        {
            var appConfig = AppConfig.Instance;
            Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["BackupLogs"]);
            Console.WriteLine(logData);
        }
      

    }
}
