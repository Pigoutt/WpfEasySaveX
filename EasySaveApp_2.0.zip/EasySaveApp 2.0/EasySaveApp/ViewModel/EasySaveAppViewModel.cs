﻿using EasySaveApp.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.Json;
using System.Diagnostics;
using System.Net.NetworkInformation;

namespace EasySaveApp.ViewModel
{
    internal class EasySaveAppViewModel
    {
        private readonly IJobManager _jobManager;
        private readonly ILogManager _logManager;
        private readonly ILocalizationProvider _localizationManager;
        private RealTimeStateFile realTimeStateFile;
        public List<BackupJob> backupJobs { get; set; }
        


        public EasySaveAppViewModel(IJobManager jobManager, ILocalizationProvider localizationManager, List<BackupJob> backupJobs)
        {
            _jobManager = jobManager;
            _localizationManager = localizationManager;
            realTimeStateFile = new RealTimeStateFile(new List<JobState>());
            this.backupJobs = backupJobs;
        }

        public void ExecuteBackupJobByName(string backupName)
        {
            _jobManager.ExecuteBackupJobByName(backupName);
        }

        public void ModifyJob(string jobName, string nwSource, string nwTarget, string nwType)
        {
            _jobManager.ModifyJob(jobName, nwSource, nwTarget, nwType);
        }

        public void DeleteJob(string jobName)
        {
            _jobManager.DeleteJob(jobName);
        }

        public BackupJob? GetBackupJobByName(string backupName)
        {
            return _jobManager.GetBackupJobByName(backupName);
        }

        public void ExecuteBackupJob(BackupJob job)
        {
            _jobManager.ExecuteBackupJob(job);
        }
        
        public List<int> ParseBackupIndices(string input)
        {
            return _jobManager.ParseBackupIndices(input);
        }
        public void ExecuteSelectedBackups(List<BackupJob> backupJobs, List<int> indices)
        {
            _jobManager.ExecuteSelectedBackups(backupJobs, indices);
        }

        public BackupJob? CreateBackupJob(string name, string source, string target, string type)
        {
            return _jobManager.CreateBackupJob(name, source, target, type);
        }

        public void ExecuteAllJobsSequentially()
        {
            _jobManager.ExecuteAllJobsSequentially();
        }

        public void ExecuteSelectedJobsSequentially(List<int> selectedJobIndices)
        {
            _jobManager.ExecuteSelectedJobsSequentially(selectedJobIndices);
        }

      

        public void SetLanguage(string language)
        {
            _localizationManager.SetLanguage(language);
        }

        public string GetLocalization(string key)
        {
            return _localizationManager.GetLocalization(key);
        }

       

        public void GeneratetoLog()
        {
            var appConfig = AppConfig.Instance;
            try
            {
                foreach (var job in backupJobs)
                {
                  

                    // Ajouter le job au journal
                    _logManager.LogBackupJob(job);
                    
                   
                       

                    
                }
                Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["logsterminé"]);
            }
            catch (Exception ex)
            {
                Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["failedlog"]); Console.WriteLine(ex.Message);
                
            }
        }

        


        public void SaveStateToFile()
        {
            var appConfig = AppConfig.Instance;
            try
            {
                string serializedState = realTimeStateFile.ToJsonString();
                File.WriteAllText("stateFile.json", serializedState);
            }
            catch (Exception ex)
            {
                Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["savestate"]); Console.WriteLine(ex.Message);

            }
        }

        public void LoadStateFromFile()
        {
            var appConfig = AppConfig.Instance;
            try
            {
                string serializedState = File.ReadAllText("stateFile.json");
                realTimeStateFile = JsonSerializer.Deserialize<RealTimeStateFile>(serializedState);
            }
            catch (Exception ex)
            {
                Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["loadstate"]); Console.WriteLine(ex.Message);

            }
        }

        

        public class CryptoManager
        {
            private const string CryptoSoftPath = "chemin_vers_CryptoSoft.exe";
            private readonly string[] allowedExtensions; // Liste des extensions autorisées

            public CryptoManager(string[] allowedExtensions)
            {
                this.allowedExtensions = allowedExtensions;
            }

            public void EncryptFile(string filePath)
            {
                var appConfig = AppConfig.Instance;
                if (IsExtensionAllowed(filePath))
                {
                    // Appeler CryptoSoft pour crypter le fichier
                    ExecuteCryptoSoft(filePath);
                }
                else
                {
                    Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["extension"]); ; Console.WriteLine(filePath); Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["nonautorisé"]);


                }
            }

            private bool IsExtensionAllowed(string filePath)
            {
                // Logique pour vérifier si l'extension du fichier est autorisée
                string fileExtension = Path.GetExtension(filePath);
                return allowedExtensions.Contains(fileExtension, StringComparer.OrdinalIgnoreCase);
            }

            private void ExecuteCryptoSoft(string filePath)
            {
                var appConfig = AppConfig.Instance;
                try
                {
                    ProcessStartInfo startInfo = new ProcessStartInfo
                    {
                        FileName = CryptoSoftPath,
                        Arguments = $"-encrypt {filePath} -output {GetEncryptedFilePath(filePath)}"
                        // Ajoutez d'autres arguments en fonction des besoins de CryptoSoft
                    };

                    using (Process process = new Process { StartInfo = startInfo })
                    {
                        process.Start();
                        process.WaitForExit();
                    }

                    Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["Cryptageréussi"]); Console.WriteLine(filePath);

                }
                catch (Exception ex)
                {
                    Console.WriteLine(appConfig.Translations[appConfig.DefaultLanguage]["Erreurcryptage"]); Console.WriteLine(filePath); Console.WriteLine(ex.Message);

                    
                }
            }

            private string GetEncryptedFilePath(string originalFilePath)
            {
                // Logique pour générer le chemin du fichier crypté
                // Par exemple, vous pouvez ajouter un préfixe au nom de fichier original
                return Path.Combine(Path.GetDirectoryName(originalFilePath), "encrypted_" + Path.GetFileName(originalFilePath));
            }
        }
    }
}
