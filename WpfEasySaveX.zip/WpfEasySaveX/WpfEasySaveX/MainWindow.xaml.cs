﻿using System;
using System.Collections.ObjectModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Win32;

using System.Linq;


namespace WpfEasySaveX
{
    public partial class MainWindow : Window
    {
        private string saveFilePath;
        private Grid grid;

        public MainWindow()
        {
            InitializeComponent();
            saveFilePath = "";
        }

        private void Logs_Click(object sender, RoutedEventArgs e)
        {
            // Crée le popup
            var popup = new Window
            {
                Title = "Save File Popup",
                Height = 200,
                Width = 400
            };

            // Contenu du popup
            grid = new Grid();
            popup.Content = grid;

            var textBlock = new TextBlock
            {
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Top,
                Margin = new Thickness(10, 10, 10, 0),
                FontSize = 16,
                Text = "Please enter a location for your save file"
            };
            grid.Children.Add(textBlock);

            var textBox = new TextBox
            {
                Name = "SaveFilePathTextBox",
                HorizontalAlignment = HorizontalAlignment.Stretch,
                VerticalAlignment = VerticalAlignment.Top,
                Margin = new Thickness(10, 40, 10, 0),
                FontSize = 14,
                Text = "C:\\Your\\Default\\Path"
            };
            grid.Children.Add(textBox);

            var backButton = new Button
            {
                Name = "Back",
                Content = "Back",
                HorizontalAlignment = HorizontalAlignment.Left,
                VerticalAlignment = VerticalAlignment.Bottom,
                Margin = new Thickness(10, 0, 0, 10),
                Width = 100,
                Height = 30
            };
            backButton.Click += Back_Click;
            grid.Children.Add(backButton);

            var continueButton = new Button
            {
                Name = "Continue",
                Content = "Continue",
                HorizontalAlignment = HorizontalAlignment.Right,
                VerticalAlignment = VerticalAlignment.Bottom,
                Margin = new Thickness(0, 0, 10, 10),
                Width = 100,
                Height = 30
            };
            continueButton.Click += Continue_Click;
            grid.Children.Add(continueButton);

            // Montre le popup en mode dialog
            if (popup.ShowDialog() == true)
            {
                // Met à jour l'interface principale avec le chemin d'accès sélectionné
                var saveFilePathTextBox = grid.Children.OfType<TextBox>().FirstOrDefault(x => x.Name == "SaveFilePathTextBox");
                if (saveFilePathTextBox != null)
                {
                    saveFilePath = saveFilePathTextBox.Text;
                    // Fais quelque chose avec le chemin d'accès, par exemple, l'afficher dans une autre fenêtre
                    MessageBox.Show($"Your save file location is: {saveFilePath}");
                }
            }
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            // Ferme le popup sans sauvegarder le chemin d'accès
            saveFilePath = ((TextBox)grid.Children.OfType<TextBox>().FirstOrDefault(x => x.Name == "SaveFilePathTextBox")).Text;

            // Obtient la fenêtre parente de manière sécurisée
            Window parentWindow = Window.GetWindow((Button)sender);

            if (parentWindow != null)
            {
                parentWindow.DialogResult = false;
                parentWindow.Close();
            }
        }
        
        private void Continue_Click(object sender, RoutedEventArgs e)
        {
            // Sauvegarde le chemin d'accès et ferme le popup
            saveFilePath = ((TextBox)grid.Children.OfType<TextBox>().FirstOrDefault(x => x.Name == "SaveFilePathTextBox")).Text;

            // Obtient la fenêtre parente de manière sécurisée
            Window parentWindow = Window.GetWindow((Button)sender);

            if (parentWindow != null)
            {
                parentWindow.DialogResult = true;
                parentWindow.Close();
            }
        }

        //JOBS

        private ObservableCollection<string> jobsList = new ObservableCollection<string>();

        private void Jobs_Click(object sender, RoutedEventArgs e)
        {
            // Crée la fenêtre des jobs
            var jobsWindow = new Window
            {
                Title = "Jobs",
                Height = 400,
                Width = 600
            };

            // Contenu de la fenêtre des jobs
            var jobsGrid = new Grid();
            jobsWindow.Content = jobsGrid;

            var titleTextBlock = new TextBlock
            {
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Top,
                Margin = new Thickness(10, 10, 10, 0),
                FontSize = 20,
                Text = "Jobs"
            };
            jobsGrid.Children.Add(titleTextBlock);

            var jobsListBox = new ListBox
            {
                Name = "JobsListBox",
                HorizontalAlignment = HorizontalAlignment.Stretch,
                VerticalAlignment = VerticalAlignment.Top,
                Margin = new Thickness(10, 40, 10, 60),
                FontSize = 14,
                ItemsSource = jobsList
            };
            jobsGrid.Children.Add(jobsListBox);

            var addButton = CreateButton("Add", 10, 10, AddJob_Click);
            jobsGrid.Children.Add(addButton);

            var deleteButton = CreateButton("Delete", 120, 10, DeleteJob_Click);
            jobsGrid.Children.Add(deleteButton);

            var editButton = CreateButton("Edit", 230, 10, EditJob_Click);
            jobsGrid.Children.Add(editButton);

            var runButton = CreateButton("RUN", 340, 10, RunJob_Click);
            jobsGrid.Children.Add(runButton);

            // Montre la fenêtre des jobs
            jobsWindow.ShowDialog();

        }

        private Button CreateButton(string content, double left, double bottom, RoutedEventHandler clickHandler)
        {
            var button = new Button
            {
                Content = content,
                HorizontalAlignment = HorizontalAlignment.Left,
                VerticalAlignment = VerticalAlignment.Bottom,
                Margin = new Thickness(left, 0, 0, bottom),
                Width = 80,
                Height = 30
            };
            button.Click += clickHandler;
            return button;
        }

        private void AddJob_Click(object sender, RoutedEventArgs e)
        {
            // Ajoute un job à la liste
            var newJob = "New Job " + (jobsList.Count + 1);
            jobsList.Add(newJob);
        }

        private void DeleteJob_Click(object sender, RoutedEventArgs e)
        {
            // Supprime le job sélectionné
            var jobsListBox = FindChild<ListBox>(Application.Current.MainWindow, "JobsListBox");
            if (jobsListBox != null && jobsListBox.SelectedItem != null)
            {
                jobsList.Remove(jobsListBox.SelectedItem.ToString());
            }
        }



        private void EditJob_Click(object sender, RoutedEventArgs e)
        {
            // Modifie le job sélectionné
            var jobsListBox = FindChild<ListBox>(Application.Current.MainWindow, "JobsListBox");
            if (jobsListBox != null && jobsListBox.SelectedItem != null)
            {
                var editedJob = ShowInputDialog("Edit Job", "Enter the new job name:");
                if (!string.IsNullOrEmpty(editedJob))
                {
                    jobsList[jobsList.IndexOf(jobsListBox.SelectedItem.ToString())] = editedJob;
                }
            }
        }

        private void RunJob_Click(object sender, RoutedEventArgs e)
        {
            // Exécute le job sélectionné (à configurer)
            var jobsListBox = FindChild<ListBox>(Application.Current.MainWindow, "JobsListBox");
            if (jobsListBox != null && jobsListBox.SelectedItem != null)
            {
                MessageBox.Show($"Running job: {jobsListBox.SelectedItem}");
                // Ajoute ici la logique pour exécuter le job
            }
        }

        private static T FindChild<T>(DependencyObject parent, string childName) where T : DependencyObject
        {
            if (parent == null)
                return null;

            T foundChild = null;

            int childrenCount = VisualTreeHelper.GetChildrenCount(parent);
            for (int i = 0; i < childrenCount; i++)
            {
                var child = VisualTreeHelper.GetChild(parent, i);

                if (child is T childType && child.GetValue(FrameworkElement.NameProperty).ToString() == childName)
                {
                    foundChild = childType;
                    break;
                }
                else
                {
                    foundChild = FindChild<T>(child, childName);

                    if (foundChild != null)
                        break;
                }
            }

            return foundChild;
        }

        private string ShowInputDialog(string title, string prompt)
        {
            // Crée la fenêtre de la boîte de dialogue d'entrée
            var inputDialog = new Window
            {
                Title = title,
                Height = 150,
                Width = 300
            };

            // Contenu de la fenêtre de la boîte de dialogue d'entrée
            var stackPanel = new StackPanel();
            inputDialog.Content = stackPanel;

            var promptTextBlock = new TextBlock
            {
                Text = prompt,
                Margin = new Thickness(10),
            };
            stackPanel.Children.Add(promptTextBlock);

            var inputTextBox = new TextBox
            {
                Margin = new Thickness(10),
            };
            stackPanel.Children.Add(inputTextBox);

            var okButton = new Button
            {
                Content = "OK",
                Width = 80,
                Height = 30,
                Margin = new Thickness(10),
            };
            okButton.Click += (sender, e) => inputDialog.DialogResult = true;
            stackPanel.Children.Add(okButton);

            // Montre la fenêtre de la boîte de dialogue d'entrée
            if (inputDialog.ShowDialog() == true)
            {
                return inputTextBox.Text;
            }

            return null;
        }

        //Delete




    }
}
